const mongoose = require('mongoose')
const mongoURI = "mongodb+srv://adityajadhav08:G9lmbinV46Iflac4@cluster0.2avz8yo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

const connectToMongo = async () => {
  try {
    mongoose.set("strictQuery", false);
    mongoose.connect(mongoURI);
    console.log("Connected to Mongo Successfully!");
  } catch (error) {
    console.log(error);
  }
};
module.exports = connectToMongo;
